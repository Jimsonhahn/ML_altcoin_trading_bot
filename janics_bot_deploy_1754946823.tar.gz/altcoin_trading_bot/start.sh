#!/bin/bash
# Quick start script for manual testing

echo "🚀 Starting Janics Freedom Factory..."

# Set environment
export FLASK_PORT=8080
export FLASK_HOST=0.0.0.0
export PYTHONPATH=$PWD

# Create directories
mkdir -p logs data

# Start the API
python3 api/app.py
