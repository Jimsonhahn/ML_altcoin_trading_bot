#!/bin/bash
set -e

echo "🚀 Setting up Janics Freedom Factory..."

# Install Python dependencies
pip3 install -r requirements.txt

# Create directories
mkdir -p logs data

# Initialize database if needed
if [ ! -f "db/trading_bot.db" ]; then
    python3 -c "from db.models import init_db; init_db()" || echo "Database init skipped"
fi

# Create systemd service
sudo tee /etc/systemd/system/janics_bot.service > /dev/null << EOF
[Unit]
Description=Janics Trading Bot
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$PWD
ExecStart=/usr/bin/python3 $PWD/api/app.py
Restart=always
Environment="FLASK_PORT=8080"
Environment="FLASK_HOST=0.0.0.0"

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable janics_bot
sudo systemctl start janics_bot

echo "✅ Setup complete!"
echo "Check status: sudo systemctl status janics_bot"
